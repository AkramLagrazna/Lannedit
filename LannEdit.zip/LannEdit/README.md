# Collaborative-Text-Editor
LAN based decentralized text editor. 

Microsoft Visual Studio 2013 (C# based project)
